const router = new VueRouter({
  mode:'history',
  base:__dirname,
  routes:[
    { path:'/', component:Home,
      children:[        
            { path:'',component:Default },
            { path:'foo',component:Foo },
            { path:'baz',component:Bar },
            { path:'with-params/:id',component:WithParams },
            { path:'relative-redirect',redirect:'foo' }           
      ]
    },
    { path:'/absolute-redirect', redirect:'/bar' },
    { path:'/dynamic-redirect/:id',
      redirect:to =>{
        //三种字段全部在
        const { hash,params,query } = to

        if(query.to === 'foo'){
          return { path:'/foo',query:null }
        }

        if( hash === '#baz'){
          return { name:'baz',hash:'' }
        }

        if(params.id){
          return '/with-params/:id'
        }else{
          return '/bar'
        }

      }
    },
        // named redirect
    { path: '/named-redirect', redirect: { name: 'baz' }},
    { path: '/redirect-with-params/:id',  redirect: '/with-params/:id' },

    // redirect with caseSensitive
    { path: '/foobar', component: Foobar, caseSensitive: true },
        // redirect with pathToRegexpOptions
    { path: '/FooBar', component: FooBar, pathToRegexpOptions: { sensitive: true }},
    // catch all redirect
    { path: '*', redirect: '/' }
  ]
})