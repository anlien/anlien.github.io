import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)


const Home = {
	template: `
	  <div class="home">
	    <h2>Home</h2>
	    <p>hello</p>
	  </div>
	`
}

//声明组件
const Parent = {
	data(){
		return {
			transitionName:'slide-left'
		}
	},
	beforeRouteUpdate(to,from,next){		
		//每次都不一样，可以判断的出来
		const toDepth = to.path.split('/').length
		const fromDepth = from.path.split('/').length

		this.transitionName = toDepth < fromDepth ? 'slide-right' : 'slide-left'
		next()

	},
	template:`
	  <div class="parent">
	  	<h2>Parent</h2>
	  	<transition :name="transitionName">
	  		<router-view class="child-view"></router-view>
	  	</transition>
	  </div>`
}