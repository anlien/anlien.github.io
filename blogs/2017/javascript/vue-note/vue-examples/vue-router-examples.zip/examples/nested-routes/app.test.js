import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const Parent = {
  template: `
    <div class="parent">
      <h2>Parent</h2>
      <router-view class="child"></router-view>
    </div>
  `
}