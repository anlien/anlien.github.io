Vue 通过建立一个虚拟 DOM 对真实 DOM 发生的变化保持追踪。

### createElement 语法
[参考](vue\src\core\vdom\create-element.js)
[参考](https://vuejs.org/v2/guide/render-function.html#createElement-Arguments)

```js 
export function createElement (
  context: Component,
  tag: any,
  data: any,
  children: any,
  normalizationType: any,
  alwaysNormalize: boolean
): VNode {}
```

* createElement 到底会返回什么呢？

其实不是一个实际的 DOM 元素。它更准确的名字可能是 createNodeDescription，因为它所包含的信息会告诉 Vue 页面上需要渲染什么样的节点，及其子节点。我们把这样的节点描述为“虚拟节点 (Virtual DOM)”，也常简写它为“VNode”。“虚拟 DOM”是我们对由 Vue 组件树建立起来的整个 VNode 树的称呼。

#### 例子
```js 
<div id="functional-attr">		
	<anchored-render myprop="1">ces</anchored-render>
</div>
```

```js 
//报错
<div id="functional-attr">		
	<anchored-render myProp="1">ces</anchored-render>
</div>
//修改为
<div id="functional-attr">		
	<anchored-render my-prop="1">ces</anchored-render>
</div>
```

####　其他
在组件中编写页面，在功能组件中进行分割和组装。
在功能函数中：
１.可以进行组件的组合
２.操作数据。可以对数据的字段进行过滤、重命名等操作，然后将修正好的数据，传递给组件中
３.对传入的props 等数据进行操作，然后传递到要使用的组件中。

功能组件可以作为中转站，选择相关的组件，然后进行创建。

Everything the component needs is passed through context, which is an object containing.
Since functional components are just functions, they’re much cheaper to render.


#### 对比代码 

```js 
Vue.component('my-special-transition', {
  template: '\
    <transition\
      name="very-special-transition"\
      mode="out-in"\
      v-on:before-enter="beforeEnter"\
      v-on:after-enter="afterEnter"\
    >\
      <slot></slot>\
    </transition>\
  ',
  methods: {
    beforeEnter: function (el) {
      // ...
    },
    afterEnter: function (el) {
      // ...
    }
  }
})
```

```js 
Vue.component('my-special-transition', {
  functional: true,
  render: function (createElement, context) {
    var data = {
      props: {
        name: 'very-special-transition',
        mode: 'out-in'
      },
      on: {
        beforeEnter: function (el) {
          // ...
        },
        afterEnter: function (el) {
          // ...
        }
      }
    }
    return createElement('transition', data, context.children)
  }
})
```

  // 由于使用原生的JavaScript来实现某些东西很简单，Vue的render函数没有提供专门的API。比如，template中的v-if和v-for。
  ```js

