
指令的职责是：
	当表达式的值改变时，将其产生的连带影响，响应式地作用于DOM.

## 计算属性

观察者，只有在数据需要计算，或者需要监听变化，而dom中不需要使用，但数据需要保存或更新时可以使用watch。
watch的设计，可以灵活的监听数据。

### data&computer&watch 的对比

* 在data中输入的数据，一般是静态的，相对来说是初始值。可以当做是声明变量的地方。
* 在computer中的数据，一般是依赖data的数据。对data进行操作和过滤后的数据，用来避免在模板中进行计算data等相关操作。
  在computer中可以使用get和set，在data变更时，可以更改其他的data数据或数据源。
  使用属性可以：
   - 可以在此处设置一些获取和更改data时的条件。
   - 可以关联和更改data中的数据。
   - 可以缓存计算的值。
   - 可以返回不同的数据类型。使用属性返回和更改时，有时返回的类型不是设置时的类型，此处要注意返回和设置的数据类型。   

  一些数据需要随着其它数据变动而变动时，可以使用computer。
* 在watch中则可以监听数据的动态变化。
  例如，在数据源中的一个变量变化，需要请求后台接口，这时使用watch比较合适。
  例如，当data的数据发生变化时，需要记录相关的数据，可以使用watch来进行记录。
  例如，computer中的数据是一般在模板中使用的数据。如果相关数据需要变动，但不使用，可以使用watch。

存疑：watch没有保留变化之前的副本，那么data是否保留变化之前的副本？

### watch的扩展
[参考](https://cn.vuejs.org/v2/api/#vm-watch)  
vm.$watch( expOrFn, callback, [options] ) 返回值：{Function} unwatch

```js 
vm.$watch('someObject', callback, {
  deep: true
})
vm.someObject.nestedValue = 123
// callback is fired
```
