### 使用插槽的目的

在编写组件后，需要将组件组合起来。例如，每个页面都有一个包含框，页面中有header、nav、content、footed等，这些内容可能是替换的。
在vue中，组件系统是 Vue 的另一个重要概念，因为它是一种抽象，允许我们使用小型、自包含和通常可复用的组件构建大型应用。
例如在一次开发中编写app、app-nav、app-header等多个组件，如何将这些组件组合起来呢？
组件是单独声名的，但将多个组件应用起来，根据不同的需求，替换不同部分的组件呢？
————————使用slot。

为了让组件可以组合，
我们需要一种方式来混合父组件的内容与子组件自己的模板。————这个过程被称为内容分发。
Vue.js实现了一个内容分发api，使用特殊的<slot>元素作为原始内容的插槽。

### 官方栗子
官方给的栗子为select2。在这个例子中：
```js 

<!--select2-->
<script type="text/x-template" id="select2-template">
      <select>
        <slot></slot><!--这个用的好 值与slot不冲突-->
      </select>
</script>

<!--使用-->
<script type="text/x-template" id="demo-template">
  <div>
    <p>Selected: {{ selected }}</p>
    <select2 :options="options" v-model="selected">
      /** 这里的值是有用的 **/
      <option disabled value="0">Select one</option>
      <option value="3">select two22</option>
    </select2>
  </div>
</script>

```

根据：
父组件模板的内容在父组件作用域内编译；
子组件模板的内容在子组件作用域内编译；

在select2中，传入options后，select2将被渲染，生成常规的内容，也就是正常渲染。
select2中的内容正常渲染与现实之后，select2中的内容，被传递到slot中，也就是将内容分发过去。
当然，分发的内容是在父作用域内编译。也就是说，在父组件中将子组件包含的内容编译后，分发到slot中。

默认插槽不仅有分发内容的作用，还有备用内容的效果。————————使用时，没有指定slot的内容时，显示slot中的内容。
在select2中，select中的内容有三处来源：
1.组件自身
2.父组件中渲染
3.slot中指定 
slot中的备用内容，只在父组件中没有指定slot的内容时显示。没有要插入的内容时才显示备用内容。

#### 具名插槽
使用单个插槽能解决单块内容传递的问题，如果有多块内容需要分发时，可以指定插槽的名称。
具名插槽将匹配内容片段中有对应 slot 特性的元素。

#### 作用域插槽
<!-- 组合时，有时需要“空瓶”，有时需要“水瓶”，需求不同，需要的“瓶种”不同。
上面的是需要的空瓶，从父组件，向子组件传递数据，那么如何从子组件向父组件传递数据呢？
使用作用域插槽。   理解可能有误-->

作用域插槽 是一种特殊类型的插槽，
作为一个可重用模板,替换已呈现的元素[already rendered elements.]（能将数据传递进来）。

在子组件中，传递数据到slot中, 就像你将通过props传递到组件中一样。(可以使用props存储数据)

在父级中，具有特殊属性scope的 <template> 元素必须存在，表示它是 作用域插槽 的模板。
scope 接收从子组件中传递的props对象(注：上面说像props传递数据)，scope的值对应的一个临时变量名。

示例翻译：
```js 
<div class="child">
	<slot text="hello from child"></slot>
	<!-- 将text数据传递到template -->
</div>

<div class="parent">
  <child>
    <template scope="props" text="hello from child">
      <span>hello from parent</span>
      <span>{{ props.text }}</span>
    </template>
  </child>
</div>

```
### slot 再次测试



 摘抄自：components-slot.html
测试绑定循环_____遍历循环显示多条数据
```js
      <!-- <p v-for="item in items">{{ item.text }}</p> -->

      <!--      
      <slot name="item" text="333"></slot>
      <slot name="item" text="333b"></slot>
      <slot name="item" text="333c"></slot>
      <slot name="item" text="333d"></slot> 
      -->      

      <!--
          对应 一个 <template></template> 正常渲染
          对应一个<li slot="item">报错</li>
      -->
      
      <!--
        <slot name="item"
          v-for="item in items"
          :text="item.text">
      -->      
      <!--<my-awesome-list :items="items"></my-awesome-list> 绑定了数据，slot正常渲染，渲染为多个 -->
      <!--
          渲染结果:
          <slot name="item" :text="item中的文本"></slot>
          <slot name="item" :text="item中的文本2"></slot>
      -->
      <!--与上面的例子类似 -->
      <!-- 没有template事，留下li时，则报错：
             —————— [Vue warn]: Duplicate presence of slot "item" found in the same render tree - this will likely cause render errors.found in       
      -->

      <!--测试：一个具名slot，对应多个li标签-->
      <!--一个具名slot，可以对应多个具名li标签-->
      <!--测试：具名中间插值，插值没有slot名称-->
      <!--li标签被分为两类，具名的按顺序排列为一组，非具名的排列为一组-->
      <!--测试：使用两个具名template，查看具名slot使用几个template-->
      <!--使用一个，而且是第二个 -->
      
      <!--具名slot的小结：-->
      <!--1.使用多个slot同名插槽，在父节点中使用多个具名li标签，slot都将被渲染。
          例如如果有4个li具名slot，有两个同名slot，将渲染8个li，同时Vue发出警告。
        -->
      <!--2.使用多个slot同名插槽，在父节点中使用多个具名template，会使用最后一个template进行渲染。
          同事没有警告
      -->
      <!--3.使用具名slot插槽只有一个。使用多个同名slot的li，具名的li标签，将被集中起来，渲染到slot中-->
      <!-- 4.使用具名slot插槽只有一个。使用多个同名template，只使用最后一个 -->

      <!--组件中的具名slot，会根据变量进行渲染，然后将参数传递给子组件-->
      <!--scope 的值对应一个临时变量名，此变量接收从子组件中传递的 prop 对象-->


      <!--其他-->
      <!-- 在slot中设置props的值，分为绑定和非绑定。绑定需要传入数据，非绑定直接设定  -***正常绑定数据 -->
```

#### 疑问

slot是如何渲染的？
编译作用域的问题：
  父组件模块的内容在父组件作用域内编译；
  子组件模块的内容在子组件作用域内编译。

——————————————理解有误！！   开始
各自编译，然后通过一些方式将元素结合。 

由作用域插槽中可知：
scope 的值对应一个临时变量，此变量接收从子组件中传递的prop对象。
此处需要看源码怎么判断的。
——————————————————————————————————结束

```js 
<div id="functionalDome">
  <anchored-heading level="1">Hello world!，{{ message }}</anchored-heading>
</div>

<!--替代-->
<script type="text/javascript">
  Vue.component("anchored-heading",{
    props:{
      level:{         
        required:true
      }       
    },
    render:function(createElement){
      return createElement("h"+this.level,this.$slots.default)
    }
  })

  new Vue({
    el:"#functionalDome",
    data:{
      message:"测试作用域在哪？"
    } 
  })
</script>
```

[参考](https://cn.vuejs.org/v2/guide/render-function.html#节点、树以及虚拟-DOM)

### prarent 中{{ 内容 }} 存储的位置
在这个例子中，在anchored-heading中的'Hello world!，{{ message }}',这些子元素被存储在示例的$slots中,此处为$slots.default。

#### 参考
官网例子：select2 可以看到内容分发与预留。


#### slot和scopedSlots 使用————————插槽
```js 
// 使用自带的slot
//使用slot时，只需在父组件中写入内容即可存储在默认位置。填名字，设置属性即可
render: function (createElement) {
  // `<div><slot></slot></div>`
  return createElement('div', this.$slots.default)  
}
  
// 此处如果绑定指令  v-for 指令，那将如何渲染呢？在slot的例子中就是这样使用的。如果没有slot，那么父元素中的slot将被丢弃（也就是说内容在父元素中）
// 由于使用原生的 JavaScript 来实现某些东西很简单，Vue 的 render 函数没有提供专用的 API。比如，template 中的 v-if 和 v-for。[参考](https://cn.vuejs.org/v2/guide/render-function.html#v-if-和-v-for)


//创建 带scopedSlots的child组件
render: function (createElement) {
  // `<div><slot :text="msg"></slot></div>` 
    return createElement("div",[
      this.$scopedSlots.default({
        text:this.msg
      })
    ])


  ```js





  第三方属性时，也就是自定义类名？
  参考：https://cn.vuejs.org/v2/guide/components.html#非-Prop-特性

  return createElement('div', [
    this.$scopedSlots.default({ // 使用时仅此一个
      text: this.msg
    })
  ])
}

// 使用scopedSlots的child组件
render( createElement){
  return createElement('div',[
    createElement('div',[
      createElement('child',{
        scopedSlots: {
          default: function(props){
            return createElement('span',props.text)
          }
        }
      })
    ])
  ])
}
```

#### 理解slot作用域
```js 
<app>
  <app-header></app-header>
  <app-footer></app-footer>
</app>
```

注意点：
* 编写的app组件不知道它会接收到什么内容。接收的内容由使用<app> 的父组件决定。
* <app> 组件很可能有自己的模板。

为了让组件可以组合，我们需要一种方式来混合父组件的内容与子组件自己的模板。这个过程被称为内容分发 (即 Angular 用户熟知的“transclusion”)。Vue.js 实现了一个内容分发 API，参照了当前 Web Components 规范草案，使用特殊的 <slot> 元素作为原始内容的插槽。

问题：
```js
render: function (createElement) {
  // `<div><slot></slot></div>`
  // 此处的this指定的是实例，还是当前的组件
  return createElement('div', this.$slots.default)

}
```

### 一个渲染函数  一个是 函数式组件