### 显示过滤/排序结果
* 有时，我们想要显示一个数组的过滤或排序副本，而不实际改变或重置原始数据。在这种情况下，可以创建返回过滤或排序数组的计算属性
* 在计算属性不适用的情况下 (例如，在嵌套 v-for 循环中) 你可以使用一个 method 方法。

```js 
<li v-for="n in even(numbers)">{{ n }}</li>

data: {
  numbers: [ 1, 2, 3, 4, 5 ]
},
methods: {
  even: function (numbers) {
    return numbers.filter(function (number) {
      return number % 2 === 0
    })
  }
}

```
### v-for with v-if
当它们处于同一节点，v-for 的优先级比 v-if 更高，这意味着 v-if 将分别重复运行于每个 v-for 循环中。


### 作用域的问题
任何数据都不会被自动传递到组件里，因为组件有自己独立的作用域。为了把迭代数据传递到组件里，我们要用props。
```js 
<my-component
  v-for="(item,index) in items"
  v-bind:item ="item"
  v-bind:index ="index"
  v-bind:key ="item.id"
>
</my-component>
```
明确组件数据的来源能够使组件在其他场合重复使用。
A common mistake is trying to bind a directive to a child property/method in the parent template.


### 非Prop特性
所谓非 prop 特性，就是指它可以直接传入组件，而不需要定义相应的 prop。


