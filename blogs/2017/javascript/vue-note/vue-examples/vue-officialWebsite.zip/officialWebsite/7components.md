[参考](https://cn.vuejs.org/v2/guide/components.html#注册)

### DOM模板的问题
* 1.使用DOM作为模板
	存在的问题：Vue 只有在浏览器解析和标准化 HTML 后才能获取模板内容。
	<ul>，<ol>，<table>，<select> 限制了能被它包裹的元素，而一些像 <option> 这样的元素只能出现在某些其它元素内部。
	变通方案：使用is属性。
	```js 
		<table>
		  <tr is="my-row"></tr>
		</table>
	```
* 2.<script type="text/x-template"></script>
* 3.JavaScript 内联模板字符串
* 4. .vue组件


* 使用 is的补充：
[参考](https://cn.vuejs.org/v2/guide/components.html#动态组件)
通过使用保留的 <component> 元素，动态地绑定到它的 is 特性,可以让多个组件可以使用同一个挂载点，并动态切换。


#### 自闭合
如果组件未经 slot 元素传递内容，你甚至可以在组件名后使用 / 使其自闭合。
```js 
<my-component/>
```
这只在字符串模板中有效。因为自闭的自定义元素是无效的 HTML，浏览器原生的解析器也无法识别它。


#### 组件中动态绑定数据
在模板中，要动态地绑定父组件的数据到子模板的 props，与绑定到任何普通的 HTML 特性相类似，就是用 v-bind。每当父组件的数据变化时，该变化也会传导给子组件：

```js 
<div>
  <input v-model="parentMsg">
  <br>
  <child v-bind:my-message="parentMsg"></child>
</div>
```
* 如果你想要用一个对象作为 props 传递所有的属性，你可以使用不带任何参数的 v-bind (即用 v-bind 替换掉 v-bind:prop-name)。
```js 
todo: {
  text: 'Learn Vue',
  isComplete: false
}


<todo-item v-bind="todo"></todo-item>

//等价于：
<todo-item
  v-bind:text="todo.text"
  v-bind:is-complete="todo.isComplete"
></todo-item>

```

使用v-bind 可以让它的值被当作JavaScript表达式计算。
```js 
<!-- 传递实际的 number -->
<comp v-bind:some-prop="1"></comp>
```

###　对组件内容的处理————slot
除非子组件模板包含至少一个 <slot> 插口，否则父组件的内容将会被丢弃。
当子组件模板只有一个没有属性的插槽时，父组件整个内容片段将插入到插槽所在的 DOM 位置，并替换掉插槽标签本身。

#### 具名插槽
<slot> 元素可以用一个特殊的属性 name 来配置如何分发内容。多个插槽可以有不同的名字。
具名插槽将匹配内容片段中有对应 slot 特性的元素。

#### 作用域插槽

### Vue.component(id,[definition])


### 可复用的组件
Vue组件的api来自三部分——————prop、事件和插槽。
* prop 允许外部环境传递数据给组件。
* 事件允许从组件内触发外部环境的副作用。
* slot允许外部环境将额外的内容组合在组件中。

### refs
$refs只在组件渲染完成后才填充，仅仅是一个直接操作子组件的应急方案。

#### 组件使用时的命名
因为自闭的自定义元素是无效的HTML，浏览器原生的解析器无法识别它。当然，在字符串模板中有效。

#### 内联模板
如果子组件有 inline-template 特性，组件将把它的内容当作它的模板，而不是把它当作分发内容。
这让模板编写起来更灵活。

```js 
<my-component inline-template>
  <div>
    <p>这些将作为组件自身的模板。</p>
    <p>而非父组件透传进来的内容。</p>
  </div>
</my-component>
```

####　提升性能的方式
组件中介绍使用v-once。
尽管在 Vue 中渲染 HTML 很快，不过当组件中包含大量静态内容时，可以考虑使用 v-once 将渲染结果缓存起来。
```js 
Vue.component('terms-of-service', {
  template: '\
    <div v-once>\
      <h1>Terms of Service</h1>\
      ...很多静态内容...\
    </div>\
  '
})
```
[v-once api](https://cn.vuejs.org/v2/api/#v-once)
只渲染元素和组件一次。随后的重新渲染，元素/组件及其所有的子节点将被视为静态内容并跳过。这可以用于优化更新性能。


* v-pre
跳过这个元素和它的子元素的编译过程。可以用来显示原始 Mustache 标签。跳过大量没有指令的节点会加快编译。
```js 
<span v-pre>{{ this will not be compiled }}</span>
```

[keep-alive](https://cn.vuejs.org/v2/api/#keep-alive)
<keep-alive> 包裹动态组件时，会缓存不活动的组件实例，而不是销毁它们。和 <transition> 相似，<keep-alive> 是一个抽象组件：它自身不会渲染一个 DOM 元素，也不会出现在父组件链中。

当组件在 <keep-alive> 内被切换，它的 activated 和 deactivated 这两个生命周期钩子函数将会被对应执行。

注：当组件不使用的时候，默认是销毁它们。


* 优化 v-cloak：
[参考](https://cn.vuejs.org/v2/api/#v-cloak)
这个指令保持在元素上直到关联实例结束编译。
和 CSS 规则如 [v-cloak] { display: none } 一起用时，这个指令可以隐藏未编译的 Mustache 标签直到实例准备完毕。



渲染函数
自定义指令
动画的过渡效果