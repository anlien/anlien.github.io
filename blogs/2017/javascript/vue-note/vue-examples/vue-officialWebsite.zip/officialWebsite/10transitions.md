过渡与动画 ————————都属于动画效果。

### 单元素/组件的过渡
* 1.自动嗅探目标元素是否应用了 CSS 过渡或动画，如果是，在恰当的时机添加/删除 CSS 类名。
* 2.如果过渡组件提供了 JavaScript 钩子函数，这些钩子函数将在恰当的时机被调用。
* 3.如果没有找到 JavaScript 钩子并且也没有检测到 CSS 过渡/动画，DOM 操作 (插入/删除) 在下一帧中立即执行。(注意：此指浏览器逐帧动画机制，和 Vue 的 nextTick 概念不同)

#### 进入/离开的类名
* 1.v-enter：定义进入过渡的开始状态。在元素被插入时生效，在下一个帧移除。
* 2.v-enter-active：定义过渡的状态。在元素整个过渡过程中作用，在元素被插入时生效，在 transition/animation 完成之后移除。这个类可以被用来定义过渡的过程时间，延迟和曲线函数。
* 3.v-enter-to: 2.1.8版及以上 定义进入过渡的结束状态。在元素被插入一帧后生效 (于此同时 v-enter 被删除)，在 transition/animation 完成之后移除。

- 1.v-leave：定义离开过渡的开始状态。在离开过渡被触发时生效，在下一个帧移除。
- 2.v-leave-active：定义过渡的状态。在元素整个过渡过程中作用，在离开过渡被触发后立即生效，在 transition/animation 完成之后移除。这个类可以被用来定义过渡的过程时间，延迟和曲线函数。
- 3.v-leave-to：定义离开过渡的结束状态。在离开过渡被触发一帧后生效 (于此同时 v-leave 被删除)，在 transition/animation 完成之后移除。

css 动画用法同css过渡，区别是在动画中v-enter类名在节点插入dom后不会立即删除，而是在animationend 事件触发时删除。

命名方式：
使用 <transition name="my-transition"> 可以重置前缀，比如 v-enter 替换为 my-transition-enter


自己注：
如果一个页面中有多个transition，若使用相同的name值，在渲染时可能多处执行。当然动画是根据data来变的，数据驱动元素的插入、移除、更新，若数据不变，动画是不会发生的。
这种写法不能绑定class的类名，只能根据transition的name来判断。在切换时，可以指定不同的name，来执行不同的动画效果。

#### 自定义类名
上面需要指定name的值，写的类名不通用。自定义类名可以解决这个问题。
* enter-class
* enter-active-class
* enter-to-class (2.1.8+)

* leave-class
* leave-active-class
* leave-to-class (2.1.8+)

它们的优先级高于普通的类名。

自己注：可以绑定类名。在操作的过程中，可以切换不同的类。类名的切换和指定基本类似，此处可能和重新渲染有关。

##### 同时使用过渡和动画 时
Vue为了知道过渡的完成，设置了相应的监听事件，可以是transitionend或animationend。
如果你使用其中任何一种，Vue 能自动识别类型并设置监听。
如果想要监听的类型（动画效果），需要使用type 特性并设置animation 或 transition

##### 如果子元素的过渡/动画 大于根元素
在这种情况下你可以用 <transition> 组件上的 duration 属性定制一个显性的过渡持续时间 (以毫秒计)。
开可以分开制定，定制进入和移出的持续时间：
```js 
<transition :duration="{ enter: 500, leave: 800 }">...</transition>
```

#### JavaScript 钩子
钩子可以结合css的 transitions/animations 一起使用，也可以单独使用。
* before-enter
* enter 
* after-enter

* enter-cancelled

* before-leave
* leave 
* after-leave

* leave-cancelled


注意：当只用 JavaScript 过渡的时候， 在 enter 和 leave 中，回调函数 done 是必须的 。否则，它们会被同步调用，过渡会立即完成。


注意：推荐对于仅使用 JavaScript 过渡的元素添加 v-bind:css="false"，Vue 会跳过 CSS 的检测。这也可以避免过渡过程中 CSS 的影响。


自己解：
用这个可以判断元素的位置及先关信息。



#### 进入的过渡动画
上面的都是元素变更时的动画。不是初始化时的动画，数据变更时会触发上面的动画（重新渲染）。

和默认进入和离开过渡一样，可以自定义css类名。
* appear-class 
* appear-active-class
* appear-to-class


自定义的JavaScript钩子为：
* before-appear
* appear 
* after-appear
* appear-cancelled

过渡动画是在进入时起作用。

此处是挂载时，进入后的动画是在数据变更时起作用的。


####  transition 多个元素的过渡————————涉及到过渡模式
可以使用 v-if/v-else  添加多个元素。通常使用一个根元素。

当有相同标签名的元素切换时，需要通过 key 特性设置唯一的值来标记以让 Vue 区分它们，否则 Vue 为了效率只会替换相同标签内部的内容。即使在技术上没有必要，给在 <transition> 组件中的多个元素设置 key 是一个更好的实践。

#### transition 自带的过渡效果——————过渡模式
transition 默认 进入和离开同时发生。 
—————— 也就是一个元素替换另一个元素时，一个开始进入，一个开始离开 ，同时发生。

同时进入和离开可以满足：
1.绝对定位时，在同一位置上，一个渐渐隐藏，一个渐渐显示效果。
2.添加 translate 制作滑动过渡。
参考：https://cn.vuejs.org/v2/guide/transitions.html#过渡模式


但不能满足其他的效果，例如一个消失完，再显示另一个等等
* in-out：新元素先进行过渡，完成之后当前元素过渡离开。（注：不需要绝对定位）
* out-in：当前元素先进行过渡，完成之后新元素过渡进入。

总结：默认、in-out、out-in 各有各的好处。此处是对元素的过渡来说的。

#### transition 多个组件的过渡
多个组件使用相同的过渡效果。
多个组件的过渡简单很多 - 我们不需要使用 key 特性。
相反，我们只需要使用动态组件。

```
<transition name="component-fade" mode="out-in">
  <component v-bind:is="view"></component>
</transition>
```

自己注：更改transition中name，可以切换不同的效果。如果使用相同的动画效果，可以使用component。内外通透，组织方式更加灵活。

transition 不会以真实的元素展示。
当有相同标签名的元素切换时，需要通过 key 特性设置唯一的值来标记以让 Vue 区分它们，否则 Vue 为了效率只会替换相同标签内部的内容。 


### 列表过渡——————transition-group
* 不同于 <transition>，它会以一个真实元素呈现：默认为一个 <span>。你也可以通过 tag 特性更换为其他元素
* 内部元素 总是需要 提供唯一的 key 属性值

* transition-group 还可以改变定位


#### v-move
会在元素的改变定位的过程中应用。通过 name 属性来自定义前缀（与之前一致），也可以通过 move-class 属性手动设置。

v-move 对于设置 过渡的切换时机 和 过渡曲线 非常有用。





