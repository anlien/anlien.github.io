## beforeCreate
[参考](https://cn.vuejs.org/v2/guide/components.html#组件间的循环引用)
当两个组件循环引用，陷入无限循环时。
要解决这个问题，我们需要在其中一个组件中告诉模块化管理系统：“A 虽然最后会用到 B，但是不需要优先导入 B”。

```js 
beforeCreate: function () {
  this.$options.components.TreeFolderContents = require('./tree-folder-contents.vue')
}
```
由此可知，可在此处导入需要的组件。或者准备组件需要使用的。

### created
在这一步，创建的实例已完成以下的相关配置：
1.data ovservation
2.computed properties
3.methods 
4.watch/event

在实例创建完成后被立即调用。

调用后：
挂载阶段还没开始，$el属性不可见。


## beforeMount
在挂载开始之前被调用

调用之后：
Create vm.$el and replace 'el' with it

## mounted
在实例安装后调用该钩子，在el被新创建的vm.$el替换。

