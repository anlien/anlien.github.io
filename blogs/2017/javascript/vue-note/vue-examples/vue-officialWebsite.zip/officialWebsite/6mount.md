#### mount
[ 参考 vm-mount](https://cn.vuejs.org/v2/api/#vm-mount)

### vm.$mount( [elementOrSelector] )
如果 Vue 实例在实例化时没有收到 el 选项，则它处于“未挂载”状态，没有关联的 DOM 元素。

这个方法返回实例自身，因而可以链式调用其它实例方法。

mount参数可选：
* 挂载到相关元素上。可以使用 vm.$mount() 手动地挂载一个未挂载的实例。
* 不进行挂载。如果没有提供 elementOrSelector 参数，模板将被渲染为文档之外的的元素，并且你必须使用原生 DOM API 把它插入文档中。


```js 

var MyComponent = Vue.extend({
  template: '<div>Hello!</div>'
})

// 创建并挂载到 #app (会替换 #app)
new MyComponent().$mount('#app')

// 同上
new MyComponent({ el: '#app' })

// 或者，在文档之外渲染并且随后挂载
var component = new MyComponent().$mount()

//component.$el 指代模板本身，编译后只是html元素
document.getElementById('app').appendChild(component.$el)

```

### 疑问
component.$el 渲染后是模板的dom，那么如何与虚拟dom进行关联？事件的监听、事件的挂载、数据的变化、如何触发的，挂载的事件是否在dom上存在？


