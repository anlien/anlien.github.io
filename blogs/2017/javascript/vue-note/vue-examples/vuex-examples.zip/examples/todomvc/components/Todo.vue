<template>
  <li class="todo" :class="{ completed: todo.done, editing: editing }">
    <div class="view">
      <input class="toggle"
        type="checkbox"
        :checked="todo.done"
        @change="toggleTodo({ todo: todo })">
      <!--触发点，显示和隐藏input-->
      <label v-text="todo.text" @dblclick="editing = true"></label>
      <button class="destroy" @click="deleteTodo({ todo: todo })"></button>
    </div>
    <input class="edit"
      v-show="editing"
      v-focus="editing"
      :value="todo.text"
      @keyup.enter="doneEdit"
      @keyup.esc="cancelEdit"
      @blur="doneEdit">
  </li>
</template>

<script>
import { mapMutations } from 'vuex'

export default {
  name: 'Todo',
  props: ['todo'],
  data () {
    return {
      editing: false
    }
  },
  directives: {
    focus(el, { value }, { context }) {
      if (value) {
        /*** 组件中编写指令，在context.$nextTick 中进行操作
             此处，指令中有一个上下文
         **/
        context.$nextTick(() => {
          el.focus()
        })
      }
    }
  },  
  /**
   * 执行操作使用methods    
   */
  methods: {
    /* 声明方法的参数,与store中的一致,调用时依据定时时传递参数 */
    ...mapMutations([
      'editTodo',
      'toggleTodo',
      'deleteTodo'
    ]),
    doneEdit (e) {
      // 此处是利用e来存储值
      // 在vue的todomv 中，使用的model，直接更改
      // 更改之前进行缓存，此处的更改，使用的是e来存储
      // 两种方式都是可以的————————应该是通用的
      // e.torget.value 是可以写的，不是只读的
      const value = e.target.value.trim()
      const { todo } = this
      if (!value) {
        this.deleteTodo({
          todo
        })
      } else if (this.editing) {
        this.editTodo({
          todo,
          value
        })
        this.editing = false
      }
    },
    cancelEdit (e) {
      //可以使用e来赋值
      e.target.value = this.todo.text
      this.editing = false
    }
  }
}
</script>
