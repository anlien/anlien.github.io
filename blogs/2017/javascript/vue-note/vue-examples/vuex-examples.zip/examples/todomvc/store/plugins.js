import { STORAGE_KEY } from './mutations'
import createLogger from '../../../src/plugins/logger'

//传入的store
//在插件中使用的，
//传入的都是store吗？
const localStoragePlugin = store => {
  store.subscribe((mutation, { todos }) => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(todos))
  })
}

//数据集中起来管理
//在 store 中进行管理
export default process.env.NODE_ENV !== 'production'
  ? [createLogger(), localStoragePlugin]
  : [localStoragePlugin]
