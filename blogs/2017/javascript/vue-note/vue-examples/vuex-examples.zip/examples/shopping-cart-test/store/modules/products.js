import  shop from '../../api/shop'
import * as types from '../mutation-types'

const state = {
	all:[]
}

const getters ={
	allProducts:state => state.all
}

const actions = {
	getAllProducts({ commit }){
		shop.getProducts(products => {
			commit(types.RECEIVE_PRODUCTS,{ products })
		})
	}
}

//数据是如何结合的？
//全部的数据是如果传出去的？
//
const mutations = {
	[types.RECEIVE_PRODUCTS](state,{ products }){
		state.all = products
	},

	[types.ADD_TO_CART](state,{ id }){
		state.all.find(p => p.id === id).inventory--
	}
}

export default {
	state,
	getters,
	actions,
	mutations
}