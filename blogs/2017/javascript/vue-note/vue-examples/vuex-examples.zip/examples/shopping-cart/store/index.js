import Vue from 'vue'
import Vuex from 'vuex'
import * as actions from './actions'
import * as getters from './getters'
import cart from './modules/cart'
import products from './modules/products'
import createLogger from '../../../src/plugins/logger'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
  actions,
  getters,
  modules: {
    cart,
    products
  },
  strict: debug,
  plugins: debug ? [createLogger()] : []
})

/**
 * 
 * 注：默认情况下，模块内部的action、mutation和getter是注册在全局命名空间的
 * 这样使得多个模块能够对同一mutation或action作出响应。
 *
 * 对于模块内部的mutation和getter，接收的第一个参数是模块的局部状态对象。
 */

