<template>
  <div class="message-section">
    <h3 class="message-thread-heading">{{ thread.name }}</h3>
    <ul class="message-list" ref="list">
      <message
        v-for="message in sortedMessages"
        :key="message.id"
        :message="message">
      </message>
    </ul>
    <textarea class="message-composer" @keyup.enter="sendMessage"></textarea>
  </div>
</template>

<script>
import Message from './Message.vue'
import { mapGetters } from 'vuex'

/**
 * 
 * 使用 mapGetter 与外部进行关联
 * getter中的属性需要经过计算
 * 外部变化，此处能getter到数据
 * 
 */
export default {
  name: 'MessageSection',
  components: { Message },
  computed: {
    ...mapGetters({
      thread: 'currentThread',
      messages: 'currentMessages'
    }),
    sortedMessages () {
      return this.messages
        .slice()
        .sort((a, b) => a.timestamp - b.timestamp)
    }
  },
  /**
   * 组件中没有用到 lastMessage
   * 可以在watch中监听
   *
   * 监听数据对象，根据相关对象进行判断，
   * 然后更改相关的属性
   * 
   */
  watch: {
    'thread.lastMessage': function () {
      this.$nextTick(() => {
        const ul = this.$refs.list
        ul.scrollTop = ul.scrollHeight
      })
    }
  },
  methods: {
    sendMessage (e) {
      const text = e.target.value
      if (text.trim()) {
        this.$store.dispatch('sendMessage', {
          text,
          thread: this.thread
        })
        e.target.value = ''
      }
    }
  }
}
</script>
