import 'babel-polyfill'
import Vue from 'vue'
import App from './components/App.vue'
import store from './store'
import { getAllMessages } from './store/actions'

Vue.config.debug = true

Vue.filter('time', timestamp => {
  return new Date(timestamp).toLocaleTimeString()
})

new Vue({
  el: '#app',
  store,
  render: h => h(App)
})


/**
 * 
 * 获得数据的方式 **
 * 在组件中，依托vue的生命周期进行获取 **
 * 在方法体中，直接调用action的方法 **
 * 注入store，使用action
 */
getAllMessages(store)
